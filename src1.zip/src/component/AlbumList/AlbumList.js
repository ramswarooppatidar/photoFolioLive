import styles from "./AlbumList.module.css"
import { useEffect, useState } from "react";
import AlbumForm from "../AlbumForm/AlbumForm";
const AlbumList = ({albumClickHandler})=>{
    const [isAlbumCreat, setIsAlbumCreate] = useState(false)
    const [albums, setAlbums] = useState([])
    const handleCreate=()=>{
        // setIsAlbumCreate(true)
        setIsAlbumCreate(prevState => !prevState);
    }
    const addAlbum=(album)=>{
        console.log("add the album name :", album.name)
        setAlbums([{text:album.name,images:album.images, id:album.id}, ...albums])
        console.log("albums : ", albums)
    }
   
    return(
        <>
        {/* <AlbumForm/> */}
        { isAlbumCreat ? <AlbumForm addAlbum={addAlbum}/> : null}
        <div className={styles.container}>
            <div className={styles.navbar}>
                <div>
                    <span> Your album </span>                    
                </div>
                <div>
                    <button onClick={handleCreate}
                    className={isAlbumCreat ? styles.cancleButton : styles.addButton}
                    >
                       { isAlbumCreat ? "cancle" : "Create Album"}
                        </button>
                </div>
            </div>
            <div className={styles.albumContainer}>
                {albums.map((album, index) => {
                    return(
                        <div key={index} onClick={()=>{albumClickHandler(album)}}>
                        <img src="https://media.istockphoto.com/id/1187393377/vector/camera-bag-modern-line-colorful-illustration-vector-design-template.jpg?s=1024x1024&w=is&k=20&c=fJV0CfTyEoz0FBllXm8evYnzOS4NyaVke_7XVBLC_z8="/>
                        <span>{album.text}</span>
                    </div>
                    )
                })}
            </div>
        </div>
        
        </>
    )
}
export default AlbumList;