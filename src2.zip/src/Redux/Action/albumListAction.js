
export const FETCH_ALBUM = "FETCH_ALBUM";

export const fetchAlbum = (albums) => ({
    type : FETCH_ALBUM,
    payload : albums
})

