//constraint
export const CREATE_ALBUM ="CREATE_ALBUM_HANDLER";

//Action
export const createAlbum = (album)=>({
    type:CREATE_ALBUM,
    payload : album
})

   
